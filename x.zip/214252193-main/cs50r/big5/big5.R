tests <- read.table("tests.tsv",
                    sep    = "\t",
                    header = TRUE,
                    stringsAsFactors = FALSE)

gender_map <- c("1" = "Male", "2" = "Female", "3" = "Other")
tests$gender <- gender_map[as.character(tests$gender)]

compute_trait <- function(prefix) {
  cols <- paste0(prefix, 1:3)
  raw  <- rowSums(tests[cols])
  round(raw / 15, 2)
}

tests$extroversion     <- compute_trait("E")
tests$neuroticism      <- compute_trait("N")
tests$agreeableness    <- compute_trait("A")
tests$conscientiousness<- compute_trait("C")
tests$openness         <- compute_trait("O")

write.csv(tests, "analysis.csv", row.names = FALSE)