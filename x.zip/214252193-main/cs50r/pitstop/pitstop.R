filename <- readline("Enter the name of a CSV file to analyze: ")
pit_data <- read.csv(filename)


total_stops   <- nrow(pit_data)
shortest_time <- min(pit_data$time)
longest_time  <- max(pit_data$time)
total_time    <- sum(pit_data$time)

cat("Total pit stops:", total_stops, "\n")
cat("Shortest pit stop:", shortest_time, "seconds\n")
cat("Longest pit stop:", longest_time, "seconds\n")
cat("Total time in pit lane:", total_time, "seconds\n")