a = input("Enter your input : ").replace(" ", "...")
print(a)
