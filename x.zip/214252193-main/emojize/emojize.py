from emoji import emojize
e = input("Input: ")
x = emojize(e, language = "alias")
print("Output:", x)
