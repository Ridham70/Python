name = input("Name: ")

print(f"goodbye, {name}")
