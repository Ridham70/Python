a = input("Enter a string : ").lower()
print(a)
