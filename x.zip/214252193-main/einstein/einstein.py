m = int(input("Enter ms: "))
c = 300000000
E = m*(c**2)
print(E)
